README

The files are organized based off of four categories
-Software(Code)
	--The software folder includes all the code for each component so you can 	  test them separately, as well as the final code used for the finished 	  product
-PCB files
	--The PCB folder include all the Altium files that you will need for the 	  project
-Hardware
	--The hardware folder includes our bill of materials for building the game
-Enclosure
	--The enclosure folder includes all the files we used to build our 	   	  enclosure on fusion 360.


